package com.cricboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrickheroApplicationTests {

	@Test
	void contextLoads() {
	}

}
