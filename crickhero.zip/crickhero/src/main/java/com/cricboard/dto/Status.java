package com.cricboard.dto;

public enum Status {
    SHIPPED,
    UNSHIPPED
}
